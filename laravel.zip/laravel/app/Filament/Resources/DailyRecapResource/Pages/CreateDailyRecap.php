<?php

namespace App\Filament\Resources\DailyRecapResource\Pages;

use App\Filament\Resources\DailyRecapResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateDailyRecap extends CreateRecord
{
    protected static string $resource = DailyRecapResource::class;
}
