<x-filament::button
    wire:click="create"
    color="primary"
>
    {{ __('filament-fullcalendar::fullcalendar.actions.new_event.label') }}
</x-filament::button>
