<?php if (isset($component)) { $__componentOriginal166a02a7c5ef5a9331faf66fa665c256 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal166a02a7c5ef5a9331faf66fa665c256 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament-panels::components.page.index','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament-panels::page'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    
    <div class="p-6 mb-8 bg-white rounded-2xl shadow-sm dark:bg-gray-800">
        <h2 class="mb-4 text-lg font-semibold text-gray-800 dark:text-gray-100">Filter Data Rekap</h2>
        <div class="grid grid-cols-1 gap-6 sm:grid-cols-3">
            
            <div>
                <label for="year" class="block text-sm font-medium text-gray-700 dark:text-gray-300">Tahun</label>
                <select id="year" wire:model="year" class="block w-full mt-1 border-gray-300 rounded-lg shadow-sm dark:bg-gray-700 dark:border-gray-600 focus:ring-primary-500 focus:border-primary-500">
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $y): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($y); ?>"><?php echo e($y); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                </select>
            </div>

            
            <div>
                <label for="month" class="block text-sm font-medium text-gray-700 dark:text-gray-300">Bulan</label>
                <select id="month" wire:model="month" class="block w-full mt-1 border-gray-300 rounded-lg shadow-sm dark:bg-gray-700 dark:border-gray-600 focus:ring-primary-500 focus:border-primary-500">
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $months; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $num => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($num); ?>"><?php echo e($name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                </select>
            </div>

            
            <div class="flex items-end">
                <button 
                    wire:click="applyFilters"
                    class="w-full px-5 py-2.5 text-sm font-medium text-white transition-colors duration-200 rounded-lg shadow-sm bg-primary-600 hover:bg-primary-500 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500">
                    Terapkan
                </button>
            </div>
        </div>
    </div>

    
    <div class="grid grid-cols-1 gap-6 md:grid-cols-3">
        <div class="p-6 text-center transition-shadow duration-200 bg-white rounded-2xl shadow-sm hover:shadow-md dark:bg-gray-800">
            <h3 class="text-sm font-medium text-gray-500 uppercase dark:text-gray-400">Sesi Hari Ini</h3>
            <p class="mt-3 text-4xl font-bold text-gray-900 dark:text-white"><?php echo e($sessionsToday); ?></p>
        </div>

        <div class="p-6 text-center transition-shadow duration-200 bg-white rounded-2xl shadow-sm hover:shadow-md dark:bg-gray-800">
            <h3 class="text-sm font-medium text-gray-500 uppercase dark:text-gray-400">
                Sesi Bulan Ini (<?php echo e($months[(int) $month] ?? ''); ?>)
            </h3>
            <p class="mt-3 text-4xl font-bold text-gray-900 dark:text-white"><?php echo e($sessionsThisMonth); ?></p>
        </div>

        <div class="p-6 text-center transition-shadow duration-200 bg-white rounded-2xl shadow-sm hover:shadow-md dark:bg-gray-800">
            <h3 class="text-sm font-medium text-gray-500 uppercase dark:text-gray-400">Total Sesi</h3>
            <p class="mt-3 text-4xl font-bold text-gray-900 dark:text-white"><?php echo e($totalSessions); ?></p>
        </div>
    </div>

    
    <div class="mt-10">
        <div class="p-6 bg-white rounded-2xl shadow-sm dark:bg-gray-800">
            <h2 class="mb-4 text-lg font-semibold text-gray-800 dark:text-gray-100">Tren Bulanan</h2>
            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split(\App\Filament\Widgets\MonthlySessionsChart::class, ['year' => $year, 'month' => $month]);

$__html = app('livewire')->mount($__name, $__params, 'lw-2077590296-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal166a02a7c5ef5a9331faf66fa665c256)): ?>
<?php $attributes = $__attributesOriginal166a02a7c5ef5a9331faf66fa665c256; ?>
<?php unset($__attributesOriginal166a02a7c5ef5a9331faf66fa665c256); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal166a02a7c5ef5a9331faf66fa665c256)): ?>
<?php $component = $__componentOriginal166a02a7c5ef5a9331faf66fa665c256; ?>
<?php unset($__componentOriginal166a02a7c5ef5a9331faf66fa665c256); ?>
<?php endif; ?>
<?php /**PATH /Users/mymac/Documents/Codes/binarkalbu/resources/views/filament/pages/session-recaps.blade.php ENDPATH**/ ?>